package com.example.tutorial5.database.docs

interface ToDoDocs {
}